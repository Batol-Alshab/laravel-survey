import { createRouter } from "vue-router";
import { createWebHistory } from "vue-router";
import DefaultLayout from "../components/DefaultLayout.vue";
import dashbord from "../views/dashbord.vue";
import login from "../views/login.vue";
import register from "../views/register.vue";
import surveys from "../views/surveys.vue";
import store from "../store";
import AuthLayout from "@/components/AuthLayout.vue";

const routes = [
  {
    path: "/",
    derirted: "dashbord",
    name: "Dashbord",
    component: DefaultLayout,
    meta: { requiresAuth: true },
    children: [
      {
        path: "/dashbord",
        name: "Dashbord",
        component: dashbord,
      },
      {
        path: "/surveys",
        name: "Surveys",
        component: surveys,
      },
    ],
  },
  {
    path: "/auth",
    redirect: "/login",
    name: "Auth",
    component: AuthLayout,
    children: [
      {
        path: "/register",
        name: "Register",
        component: register,
      },
      {
        path: "/login",
        name: "Login",
        component: login,
      },
    ],
  },
];
const router = createRouter({
  history: createWebHistory(),
  routes,
});
router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth && !store.state.user.token) {
    next({ name: "Login" });
  } else if (
    store.state.user.token &&
    (to.name === "Login" || to.name === "Register")
  ) {
    next({ name: "Dashbord" });
  } else {
    next();
  }
});

export default router;
